from http.server import HTTPServer, SimpleHTTPRequestHandler
import argparse
import base64

class AuthHandler(SimpleHTTPRequestHandler):
    AUTH_KEY = ""

    def do_AUTHHEAD(self):
        self.send_response(401)
        self.send_header('WWW-Authenticate', 'Basic realm="Auth Server"')
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(b'Authentication required.')

    def do_GET(self):
        auth_header = self.headers.get('Authorization')
        if auth_header == f"Basic {self.AUTH_KEY}":
            super().do_GET()
        else:
            self.do_AUTHHEAD()

def main():
    parser = argparse.ArgumentParser(description="Basic Auth HTTP Server")
    parser.add_argument('--username', required=True, help="Username for Basic Authentication")
    parser.add_argument('--password', required=True, help="Password for Basic Authentication")
    parser.add_argument('--port', type=int, default=8443, help="Port to run the server")
    args = parser.parse_args()

    AuthHandler.AUTH_KEY = base64.b64encode(f"{args.username}:{args.password}".encode()).decode()
    server_address = ('0.0.0.0', args.port)
    httpd = HTTPServer(server_address, AuthHandler)
    print(f"Serving on port {args.port}")
    httpd.serve_forever()

if __name__ == "__main__":
    main()

